with open('./test/testdata/netrc/netrc', encoding='utf-8') as fp:
    print(fp.read())
