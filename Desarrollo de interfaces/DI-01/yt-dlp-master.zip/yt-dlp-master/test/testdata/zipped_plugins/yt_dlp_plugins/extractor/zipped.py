from yt_dlp.extractor.common import InfoExtractor


class ZippedPluginIE(InfoExtractor):
    _VALID_URL = 'zippedpluginie'
    pass
